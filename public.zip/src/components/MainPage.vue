<template>
  <div>
 
  <div>
      <div class="s2container ">
          <img src="../assets/img/s2/Banner.jpg" alt="s2img " class="s2container__img need-hide">
      </div>
    </div>
  <div>
      <div class="s3container">
          <div class="s3container__text">
              <p class="s3container__text__title">Следите за нашими проектами</p>
              <p class="s3container__text__subtitle">Хорошо известно, что читатель будет отвлекаться <br>на читабельный контент
              </p>
          </div>
      </div>
    </div>
  <div>
       <div class="s4container">
          <a href="#" class="s4container__link">
              <img class="s4container__link__img  imgtopright" src="../assets/img/s4/Photo1.png" alt="">
              <div class="s4container__link__subimg">
                  <div class="s4container__link__subimg__text">
                    <span class="s4container__link__subimg__text__title"> Современная кухня</span>
                    <p>Декор / Планировка</p>
                  </div>
                  <button class="s4container__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                  </button>
              </div>
        </a>
          <a href="#" class="s4container__link">
              <img class="s4container__link__img  imgtopleft" src="../assets/img/s4/Photo2.png" alt="">
              <div class="s4container__link__subimg">
                  <div class="s4container__link__subimg__text">
                  <span class="s4container__link__subimg__text__title"> Современная кухня</span>
                  <p>Декор / Планировка</p></div>
                  <button class="s4container__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      </button>
              </div></a>
              <a href="#" class="s6container__link">
                  <img class="s4container__link__img  imgbottomright" src="../assets/img/s4/Photo3.png" alt="">
                  <div class="s4container__link__subimg">
                      <div class="s4container__link__subimg__text">
                      <span class="s4container__link__subimg__text__title"> Современная кухня</span>
                      <p>Декор / Планировка</p></div>
                      <button class="s4container__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>
                          </button>
                  </div>
              </a>
              <a href="#" class="s4container__link">
                  <img class="s4container__link__img  imgbottomleft" src="../assets/img/s4/Photo4.png" alt="">
                  <div class="s4container__link__subimg">
                      <div class="s4container__link__subimg__text">
                      <span class="s4container__link__subimg__text__title"> Современная кухня</span>
                      <p>Декор / Планировка</p></div>
                      <button class="s4container__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>
                          </button>
                  </div>
              </a>
              
                 
      </div> 
    </div> 
  <div>
      <div class="s5container">
          <div class="s5container__block">
          <div class="s5container__block__text">
             <span class="s5container__block__text__title">12</span>
             <span class="s5container__block__text__subtitle">Лет опыта</span>
          </div>
         
          <div class="s5container__block__text">
              <span class="s5container__block__text__title">85</span>
              <span class="s5container__block__text__subtitle">Успешных проектов</span>
          </div>
          <div class="s5container__block__text">
                  <span class="s5container__block__text__title">15</span>
                  <span class="s5container__block__text__subtitle">Проектов в работе</span>
          </div>
          <div class="s5container__block__text">
                  <span class="s5container__block__text__title">95</span>
                  <span class="s5container__block__text__subtitle">Счастливых клиентов</span>
              </div>
          </div>

      </div>
  </div>
  <div>   
    <div class="s6container">
        <div class="s6container__text">
            <div class="s6container__text__up">
              <span class="s6container__text__up__title">Статьи и Новости</span>
            </div>
            <div class="s6container__text__down"><span class="s6container__text__subtitle">Хорошо известно, что читатель будет отвлекаться <br> на читабельный контент
              </span>
            </div>
        </div>
        <div class="s6container__btn">
            <a href="#" class="s6container__btn__link">
              <img class="s6container__btn__link__img" src="../assets/img/s6/Image1.png" alt="">
              <span class="s6container__btn__link__text">
                  Создадим лучший макет перепланировки
              </span>
              <div class="s6container__btn__link__subimg">
                  <div> 
                  <span class="s6container__btn__link__subimg__text"> 26 Декабрь,2022 </span>
                  </div>
                  <button class="s6container__btn__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      </button>
              </div>
            </a>
          <a href="#" class="s6container__btn__link">
              <img class="s6container__btn__link__img" src="../assets/img/s6/Image2.png" alt="">
              <span class="s6container__btn__link__text">
                  Лучшие интерьерные идеи по низкой цене
              </span>
              <div class="s6container__btn__link__subimg">
                  <div> 
                  <span class="s6container__btn__link__subimg__text"> 26 Декабрь,2022 </span>
                  </div>
                  <button class="s6container__btn__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      </button>
              </div>
          </a>
          <a href="#" class="s6container__btn__link">
              <img class="s6container__btn__link__img" src="../assets/img/s6/Image3.png" alt="">
              <span class="s6container__btn__link__text">
                  Лучшие интерьерные решения для офисов 
              </span>
              <div class="s6container__btn__link__subimg">
                  <div> 
                  <span class="s6container__btn__link__subimg__text"> 26 Декабрь,2022 </span>
                  </div>
                  <button class="s6container__btn__link__subimg__btn"><svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 19L9 10L1 1" stroke="#292F36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      </button>
              </div>
          </a></div>         
      </div> 
    </div> 
  
  </div>
</template>

<script>
export default {
  name: 'MainPage',
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
@import '../assets/filesforstyle/vars';

.imgtopleft{border-top-left-radius: 20%;}
.imgtopright{border-top-right-radius: 20%;}
.imgbottomleft{border-bottom-left-radius: 20%;}
.imgbottomright{border-bottom-right-radius: 20%;}
.body {
  font-family: 'Jost', 'DM Serif Display',sans-serif;
}

.s2container {
  background-color: $colorS2;
  @include ParamWHM($widthS2, $heightS2, 360px, none, none, none);
 
}

.s3container {
  @include ParamWHM($widthS3, $heightS3, 360px, none, 100px, none);
  @include ParamPosition(none, flex, center, none);
  &__text {
      &__title {
          @include ParamText($colorS3, 'DM Serif Display', 50px, 400, none, center);
      }
      &__subtitle {
          @include ParamText($colorS3, Jost, 22px, 300, none, center);
          margin-top: 3.3px;
      }
  }
}

.s4container {
  @include ParamWHM($widthS4, $heightS4, 360px, none, 30px, none);
  display: grid;
  flex-wrap: wrap;
  justify-content: space-evenly;
  grid-template-columns: repeat(2, 549px);
  grid-auto-flow: dense;
    &__link {
      &__subimg{ 
        @include ParamWHM(549px, 70px, none, none, 24px, 50px);
        @include ParamPosition(none, flex, space-between, none);
        &__text {
          @include ParamText(#292F36, Jost, 22px, 400, none, center);
          &__title{ 
            @include ParamText(#292F36, Jost, 25px, 400, none, center);
          }
        }
        &__btn{
          width: 70px; 
          height: 70px; 
          background-color: #F4F0EC; 
          border-radius: 50%; 
          border: none; 
      }
      }
    }
  
}

.s5container{
  @include ParamWHM($widthS5, $heightS5, none, none, 135px, none);
  background-color: $colorS5;
 @include ParamPosition(none, flex, center, center);

  &__block{
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      padding: 0px;
      gap: 76px;
      &__text {
          
      @include ParamWHM(246px,155px, none, none, none, none);
      @include ParamPosition(none, flex, center, center);
      flex-direction:column;
      
           &__title {
          @include ParamText($colorS5title, Jost, 85px, 400, center, none);
          }
          &__subtitle{ @include ParamText($colorS5subtitle, Jost, 20px, 400, center, none);
          }
      }
  }
}
.s6container {
  @include ParamWHM($widthS6, $heightS6, 360px, none, 150px, none);
  &__text{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0px;
    gap: 12px;
    &__up{
      width: 362px;
      text-align: center;
      &__title {
          @include ParamText(#222, Jost, 50px, 400, none, center);   
      } 
    }
    &__down{ 
      width: 811px;
      text-align: center;
      margin-bottom:30px;
      &__subtext {
      @include ParamText(#222, Jost, 22px, 400, none, center);
      }
    }
  }
  &__btn{
    display: grid;
    flex-wrap: wrap;
    justify-content: center;
    grid-template-columns: repeat(3, 382px);
    grid-auto-flow: dense;
    gap: 16px;
    &__link {
      &__text {
         @include ParamText(#292F36, Jost, 25px, 400, none, none);
      }
      &__subimg{
        @include ParamWHM(350px, 70px, none, none, 24px, 50px);
        @include ParamPosition(none, flex, space-between, none);
          &__text {
            @include ParamText(#292F36, Jost, 16px, 400, none, center);
          }
          &__btn{
            width: 52px; 
            height: 52px; 
            background-color: #F4F0EC; 
            border-radius: 50%; 
            border: none; 
          }
      }
    }

  }
}




</style>
