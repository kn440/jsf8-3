<template>
    <header class="header center">
        <div class="header__left">
                <a href="#"><img class="header__left__img" src="../assets/img/s1/Logo.png" alt="logo"></a>
            </div>
        <nav class="header__right">
                <a class="header__right__link" href="#">Домой</a>
                <a class="header__right__link" href="#">Проект</a>
                <a class="header__right__link" href="#">Блок</a>
        </nav>
    </header>
</template>

<script>
export default {
  name: 'MainHeader',
  
}
</script>


<style scoped lang="scss">
@import '../assets/filesforstyle/vars';
.header {
    @include ParamWHM($widthS1, $heightS1, 360px, none, 69px, 69px);
    min-height: 75px;
    background: #fff;
    @include ParamPosition(none, flex, space-between, center);
    flex-direction: row;
    flex-wrap: wrap;
    &__left {
        display: flex;
        align-items: center;
        gap: 41px;
        &__img {
            height: 50px;
        }
    }
    &__right {
        display: flex;
        gap: 33px;
        &__link {
            @include ParamText(#292F36, Jost, 20px, 300, none, none);
        }
    }
  }

</style>
