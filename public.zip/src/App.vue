<template>
  <div id="app">
    <MainHeader/>
    <MainPage/>
    <MainFooter/>
  </div>
</template>

<script>
import MainFooter from './components/MainFooter.vue';
import MainHeader from './components/MainHeader.vue';
import MainPage from './components/MainPage.vue'


export default {
  name: 'App',
  components: {
    MainPage,
    MainHeader,
    MainFooter

  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
